from django.urls import path
# from .views import get_ocr

urlpatterns = [
    path('ocr/', get_ocr),
    # path('budget', get_budget),

]