from django.shortcuts import render
# from .models import Recipt, Budget
# Create your views here.
from django.http import JsonResponse, HttpResponse


# Create your views here.
