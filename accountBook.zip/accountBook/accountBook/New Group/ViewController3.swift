//
//  ViewController3.swift
//  accountBook
//
//  Created by 이현수 on 2023/06/29.
//
import UIKit


class ViewController3: UIViewController{
    
    @IBOutlet var btn1: UIButton!
    
    @IBOutlet var btn2: UIButton!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    




            
            
        }
        
